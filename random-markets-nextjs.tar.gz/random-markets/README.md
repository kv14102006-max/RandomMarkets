# RandomMarkets — Next.js Frontend

Provably fair USDC coin flip platform on Base, powered by Pyth Entropy.

## Quick Start

```bash
npm install
npm run dev
# → http://localhost:3000
```

## Project Structure

```
random-markets/
├── app/
│   ├── layout.js          # Root layout + metadata
│   ├── page.js            # Main SPA shell with client-side routing
│   └── blocked/page.js    # Geo-blocked landing page
├── components/
│   ├── Icons.jsx           # All SVG icons
│   ├── UI.jsx              # Avatar, AnimatedCoin, MatchCard, GeoDisclaimer
│   ├── Navigation.jsx      # Header + BottomNav (Polymarket-style)
│   ├── Modals.jsx          # CreateModal + DetailModal
│   └── pages/
│       ├── MatchesPage.jsx     # Main markets grid (stats bar removed)
│       ├── LeaderboardPage.jsx # Podium + table
│       ├── BetsPage.jsx        # User bet history
│       ├── ReferralPage.jsx    # Referral link + stats + claim
│       ├── FaqPage.jsx         # How It Works
│       ├── TermsPage.jsx       # Terms & Conditions
│       ├── PrivacyPage.jsx     # Privacy Policy
│       └── AboutPage.jsx       # About
├── lib/
│   └── constants.js        # Config, fees, contract addresses, mock data
├── styles/
│   └── globals.css         # Full design system (dark theme, responsive)
├── middleware.js            # Geo-restriction (placeholder, ready to enable)
├── next.config.js
├── jsconfig.json            # Path aliases (@/*)
└── package.json
```

## Design

- **Theme**: Deep dark (#080b11 bg), green accent (#22c55e), USDC blue (#2775CA)
- **Font**: DM Sans (UI) + JetBrains Mono (numbers)
- **Mobile**: Polymarket-style bottom tab bar (Markets, Ranks, My Bets, Refer, More)
- **Desktop**: Top nav with "More" dropdown
- **Stats bar**: Removed (was mock data, wasted space)

## Tech Stack

- Next.js 14 (App Router)
- RainbowKit + wagmi + viem (wallet connection — wire up after contract deploy)
- Pyth Entropy (on-chain randomness)
- USDC on Base (ERC-20 bets)

## Geo-Restriction

Edit `middleware.js` to uncomment the geo check and add blocked country codes:

```js
const BLOCKED_COUNTRIES = ["US", "GB"];
```

Works automatically on Vercel (uses `x-vercel-ip-country` header).

## USDC Contract Changes (PENDING)

The current smart contract (RandomMarkets.sol) uses native ETH. When rebuilding for USDC:

### Required Changes:
1. Add USDC token import: `IERC20(0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913)` (Base mainnet)
2. Replace `msg.value` with `token.transferFrom(msg.sender, address(this), amount)`
3. Users must `approve()` the contract before creating/joining matches
4. Winner payout via `token.transfer(winner, amount * 2)`
5. Fee collection via `token.transfer(feeCollector, feeAmount)`
6. Entropy fee still paid in native ETH (separate from USDC bet)
7. `getJoinerCost()` returns USDC amount + ETH entropy fee separately
8. USDC uses 6 decimals (not 18) — all math must account for this

### Also Pending:
- Pyth Entropy V2 upgrade (IEntropyV2, getFeeV2)
- OpenZeppelin Pausable
- Match expiry / timeout refund
- Referral mapping + fee split on-chain
- Blocklist for restricted addresses
- Emergency withdrawal function

## Connecting to Real Contract

1. Deploy contract to Base Sepolia
2. Update `CONTRACT_ADDRESS` in `lib/constants.js`
3. Replace mock data generators with wagmi hooks reading from contract
4. Wire RainbowKit ConnectButton into Header
5. Add USDC approval flow before create/join

## License

Private — not open source.
```
