"use client";
import { useState } from "react";
import { CREATOR_FEE, JOINER_FEE, SYM } from "@/lib/constants";
import { Icons, HeadsSVG, TailsSVG, LiveDot } from "./Icons";
import { Avatar, AnimatedCoin } from "./UI";

const MN = "var(--mono)";

export function CreateModal({ close, balance }) {
  const [amt, setAmt] = useState("");
  const [choice, setChoice] = useState("heads");

  const n = parseInt(amt) || 0;
  const fee = n * CREATOR_FEE;
  const total = n + fee;
  const valid = n >= 1 && n === Math.floor(n) && total <= balance;

  return (
    <div className="modal-overlay" onClick={close}>
      <div className="modal-content" onClick={e => e.stopPropagation()}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
          <div>
            <div style={{ fontSize: 17, fontWeight: 800 }}>Create Match</div>
            <div style={{ color: "var(--text-muted)", fontSize: 11, marginTop: 1 }}>Set stake and pick a side</div>
          </div>
          <button onClick={close} style={{ background: "rgba(255,255,255,.03)", border: "none", color: "var(--text-muted)", cursor: "pointer", padding: 7, borderRadius: 8 }}>
            {Icons.x()}
          </button>
        </div>

        {/* Amount */}
        <div style={{ marginBottom: 18 }}>
          <label style={{ fontSize: 9, fontWeight: 700, color: "var(--text-muted)", display: "block", marginBottom: 5, textTransform: "uppercase", letterSpacing: 1 }}>
            Amount ({SYM})
          </label>
          <div style={{ position: "relative" }}>
            <span style={{ position: "absolute", left: 13, top: "50%", transform: "translateY(-50%)", fontSize: 18, fontWeight: 800, color: "var(--usdc)" }}>$</span>
            <input
              className="input"
              type="text" inputMode="numeric" placeholder="0"
              value={amt}
              onChange={e => setAmt(e.target.value.replace(/[^0-9]/g, ""))}
              style={{ paddingLeft: 32, fontSize: 20, fontWeight: 800, fontFamily: MN, height: 50 }}
            />
          </div>
          <div style={{ display: "flex", gap: 4, marginTop: 6, flexWrap: "wrap" }}>
            {[5, 10, 25, 50, 100, 250, 500, 1000].map(p => (
              <button
                key={p}
                onClick={() => setAmt(String(p))}
                style={{
                  padding: "4px 10px", borderRadius: 7, fontSize: 11, fontWeight: 600,
                  cursor: "pointer", fontFamily: MN,
                  background: n === p ? "var(--green-dim)" : "rgba(255,255,255,.02)",
                  border: `1px solid ${n === p ? "var(--green-border)" : "var(--border)"}`,
                  color: n === p ? "var(--green)" : "var(--text-muted)",
                }}
              >${p}</button>
            ))}
          </div>
        </div>

        {/* Pick */}
        <div style={{ marginBottom: 18 }}>
          <label style={{ fontSize: 9, fontWeight: 700, color: "var(--text-muted)", display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: 1 }}>
            Your Pick
          </label>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
            {["heads", "tails"].map(s => {
              const sel = choice === s;
              const isH = s === "heads";
              return (
                <button
                  key={s}
                  onClick={() => setChoice(s)}
                  style={{
                    padding: 14, borderRadius: 11, cursor: "pointer", textAlign: "center",
                    background: sel ? (isH ? "var(--green-dim)" : "var(--red-dim)") : "var(--bg)",
                    border: `2px solid ${sel ? (isH ? "var(--green)" : "var(--red)") : "var(--border)"}`,
                    transition: "all .12s",
                  }}
                >
                  {isH ? <HeadsSVG size={32} /> : <TailsSVG size={32} />}
                  <div style={{ fontWeight: 700, fontSize: 12, marginTop: 5, color: sel ? (isH ? "var(--green)" : "var(--red)") : "var(--text-muted)" }}>
                    {isH ? "Heads" : "Tails"}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        <div className="info-note" style={{ marginBottom: 10 }}>
          {Icons.info()} Creator fee: 1.5% on top of bet
        </div>

        {n >= 1 && (
          <div style={{ padding: 12, background: "rgba(34,197,94,.02)", borderRadius: 9, border: "1px solid rgba(34,197,94,.06)", marginBottom: 14 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5, fontSize: 12 }}>
              <span style={{ color: "var(--text-secondary)" }}>Bet</span>
              <span style={{ fontFamily: MN }}>${n}</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5, fontSize: 12 }}>
              <span style={{ color: "var(--text-secondary)" }}>Fee (1.5%)</span>
              <span style={{ fontFamily: MN, color: "var(--text-muted)" }}>${fee.toFixed(2)}</span>
            </div>
            <div style={{ borderTop: "1px solid rgba(255,255,255,.03)", paddingTop: 5, display: "flex", justifyContent: "space-between", fontSize: 13 }}>
              <span style={{ fontWeight: 600 }}>Total</span>
              <span style={{ fontWeight: 800, fontFamily: MN }}>${total.toFixed(2)} {SYM}</span>
            </div>
          </div>
        )}

        <button className="btn-primary" disabled={!valid} style={{ width: "100%", justifyContent: "center", padding: 12, fontSize: 13, borderRadius: 11 }}>
          {Icons.plus(13)} Create{n > 0 ? ` · $${total.toFixed(2)}` : ""}
        </button>
      </div>
    </div>
  );
}

export function DetailModal({ match, close, balance }) {
  const [side, setSide] = useState(null);
  const [step, setStep] = useState(0); // 0=pick, 1=joining, 2=flipping, 3=result
  const [result, setResult] = useState(null);

  const m = match;
  const fee = m.betAmount * JOINER_FEE;
  const total = m.betAmount + fee;
  const canJoin = total <= balance && side && m.status === "live" && step === 0;

  const doFlip = () => {
    if (!canJoin) return;
    setStep(1);
    setTimeout(() => setStep(2), 700);
    setTimeout(() => {
      const r = Math.random() > 0.5 ? "heads" : "tails";
      setResult(r);
      setStep(3);
    }, 3000);
  };

  return (
    <div className="modal-overlay" onClick={close}>
      <div className="modal-content" onClick={e => e.stopPropagation()} style={{ maxWidth: 440 }}>
        {/* Header */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
          {step === 0 && m.status === "live" && (
            <div style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 11, fontWeight: 700, color: "var(--green)" }}>
              <LiveDot /> Open Match
            </div>
          )}
          {step > 0 && step < 3 && (
            <div style={{ fontSize: 11, fontWeight: 700, color: "var(--yellow)", animation: "stepPulse 1s ease infinite" }}>
              {step === 1 ? "Submitting..." : "Flipping..."}
            </div>
          )}
          {(step === 3 || m.status === "completed") && (
            <span style={{ fontSize: 11, color: "var(--text-secondary)" }}>Complete</span>
          )}
          <button onClick={close} style={{ background: "rgba(255,255,255,.03)", border: "none", color: "var(--text-muted)", cursor: "pointer", padding: 5, borderRadius: 7 }}>
            {Icons.x(16)}
          </button>
        </div>

        {/* Progress steps */}
        {step > 0 && (
          <div style={{ display: "flex", justifyContent: "center", gap: 3, marginBottom: 14 }}>
            {["Join", "Flip", "Result"].map((s, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 3 }}>
                <div style={{
                  width: 20, height: 20, borderRadius: "50%", fontSize: 9, fontWeight: 700,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  background: step > i ? "var(--green)" : "var(--border)",
                  color: step > i ? "#fff" : "var(--text-muted)", transition: "all .3s",
                }}>
                  {step > i ? Icons.check(9, "#fff") : i + 1}
                </div>
                <span style={{ fontSize: 9, fontWeight: 600, color: step > i ? "var(--green)" : "var(--text-muted)" }}>{s}</span>
                {i < 2 && <div style={{ width: 16, height: 1, background: step > i + 1 ? "var(--green)" : "var(--border)" }} />}
              </div>
            ))}
          </div>
        )}

        {/* Coin */}
        <div style={{ marginBottom: 16, textAlign: "center" }}>
          <AnimatedCoin flipping={step === 2} result={result || m.result || "heads"} />
          {step === 3 && result && (
            <div style={{ marginTop: 10, animation: "fadeUp .3s ease" }}>
              <div style={{ fontSize: 16, fontWeight: 800, color: result === "heads" ? "var(--green)" : "var(--red)" }}>
                {result === "heads" ? "Heads!" : "Tails!"}
              </div>
              <div style={{ color: "var(--text-secondary)", fontSize: 12, marginTop: 1 }}>
                {result === side ? "You won!" : "You lost!"}
              </div>
            </div>
          )}
        </div>

        {/* VS */}
        <div style={{
          display: "flex", alignItems: "center", justifyContent: "center", gap: 14,
          marginBottom: 14, padding: 14, background: "var(--bg)", borderRadius: 11, border: "1px solid var(--border)",
        }}>
          <div style={{ textAlign: "center", flex: 1 }}>
            <div style={{ display: "flex", justifyContent: "center" }}><Avatar user={m.creator} size={32} /></div>
            <div style={{ fontWeight: 600, fontSize: 11, marginTop: 5 }}>{m.creator.name.slice(0, 12)}</div>
            <div style={{ fontSize: 9, color: m.creatorChoice === "heads" ? "var(--green)" : "var(--red)", fontWeight: 600 }}>
              {m.creatorChoice === "heads" ? "Heads" : "Tails"}
            </div>
          </div>
          <div style={{ fontSize: 9, fontWeight: 800, color: "var(--text-muted)", background: "var(--border)", padding: "3px 8px", borderRadius: 5 }}>VS</div>
          <div style={{ textAlign: "center", flex: 1 }}>
            {m.opponent ? (
              <>
                <div style={{ display: "flex", justifyContent: "center" }}><Avatar user={m.opponent} size={32} /></div>
                <div style={{ fontWeight: 600, fontSize: 11, marginTop: 5 }}>{m.opponent.name.slice(0, 12)}</div>
              </>
            ) : (
              <>
                <div style={{
                  width: 32, height: 32, borderRadius: 8, background: "var(--border)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  margin: "0 auto", border: "2px dashed var(--border-hover)",
                }}>
                  {Icons.users(12)}
                </div>
                <div style={{ fontSize: 10, color: "var(--text-muted)", marginTop: 5 }}>Waiting...</div>
              </>
            )}
          </div>
        </div>

        {/* Pot */}
        <div style={{ textAlign: "center", marginBottom: 16 }}>
          <div style={{ fontSize: 24, fontWeight: 800, fontFamily: MN, color: "var(--green)" }}>
            ${(m.betAmount * (m.opponent ? 2 : 1)).toLocaleString()}
            <span style={{ fontSize: 10, color: "var(--text-muted)", fontWeight: 500, marginLeft: 3 }}>{SYM}</span>
          </div>
          <div style={{ fontSize: 10, color: "var(--text-muted)" }}>50/50 odds</div>
        </div>

        {/* Join section */}
        {m.status === "live" && step === 0 && (
          <>
            <label style={{ fontSize: 9, fontWeight: 700, color: "var(--text-muted)", display: "block", marginBottom: 6, textTransform: "uppercase", letterSpacing: 1 }}>
              Pick Your Side
            </label>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6, marginBottom: 12 }}>
              {["heads", "tails"].map(s => {
                const taken = s === m.creatorChoice;
                const sel = side === s;
                const isH = s === "heads";
                return (
                  <button
                    key={s}
                    onClick={() => !taken && setSide(s)}
                    style={{
                      padding: 12, borderRadius: 9, textAlign: "center",
                      cursor: taken ? "not-allowed" : "pointer",
                      background: sel ? (isH ? "var(--green-dim)" : "var(--red-dim)") : "transparent",
                      border: `2px solid ${taken ? "var(--border)" : sel ? (isH ? "var(--green)" : "var(--red)") : "var(--border)"}`,
                      opacity: taken ? 0.25 : 1, transition: "all .12s",
                    }}
                  >
                    {isH ? <HeadsSVG size={28} muted={taken} /> : <TailsSVG size={28} muted={taken} />}
                    <div style={{ fontWeight: 700, fontSize: 11, marginTop: 3, color: taken ? "var(--text-muted)" : sel ? (isH ? "var(--green)" : "var(--red)") : "var(--text-secondary)" }}>
                      {isH ? "Heads" : "Tails"}
                    </div>
                    {taken && <div style={{ fontSize: 8, color: "var(--text-muted)" }}>Taken</div>}
                  </button>
                );
              })}
            </div>

            <div className="info-note" style={{ marginBottom: 8 }}>{Icons.info()} Joiner fee: 2.5% + small entropy fee</div>

            <div style={{ padding: 10, background: "rgba(255,255,255,.01)", borderRadius: 8, border: "1px solid var(--border)", marginBottom: 12 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 3, fontSize: 11 }}>
                <span style={{ color: "var(--text-secondary)" }}>Bet</span>
                <span style={{ fontFamily: MN }}>${m.betAmount.toLocaleString()}</span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 3, fontSize: 11 }}>
                <span style={{ color: "var(--text-secondary)" }}>Fee (2.5%)</span>
                <span style={{ fontFamily: MN, color: "var(--text-muted)" }}>${fee.toFixed(2)}</span>
              </div>
              <div style={{ borderTop: "1px solid rgba(255,255,255,.02)", paddingTop: 3, display: "flex", justifyContent: "space-between", fontSize: 12 }}>
                <span style={{ fontWeight: 600 }}>Total</span>
                <span style={{ fontWeight: 800, fontFamily: MN }}>${total.toFixed(2)}</span>
              </div>
            </div>

            <button className="btn-primary" disabled={!canJoin} onClick={doFlip} style={{ width: "100%", justifyContent: "center", padding: 12, fontSize: 13, borderRadius: 11 }}>
              {Icons.coin(15)} Join & Flip · ${total.toFixed(2)}
            </button>
          </>
        )}
      </div>
    </div>
  );
}
