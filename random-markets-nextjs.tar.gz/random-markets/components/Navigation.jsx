"use client";
import { useState } from "react";
import { SYM } from "@/lib/constants";
import { Icons } from "./Icons";

const MN = "var(--mono)";

export function Header({ page, onNavigate, balance = 4827 }) {
  const [moreOpen, setMoreOpen] = useState(false);

  const navItems = [
    { id: "matches", label: "Markets" },
    { id: "leaderboard", label: "Leaderboard" },
    { id: "bets", label: "My Bets" },
    { id: "referral", label: "Referrals" },
  ];
  const moreItems = [
    { id: "faq", label: "How It Works", icon: Icons.help(14) },
    { id: "about", label: "About", icon: Icons.info(14) },
    { id: "terms", label: "Terms", icon: Icons.file(14) },
    { id: "privacy", label: "Privacy", icon: Icons.shield(14) },
  ];

  const nav = (p) => { onNavigate(p); setMoreOpen(false); };

  return (
    <header style={{
      borderBottom: "1px solid var(--border)",
      background: "rgba(8,11,17,.94)",
      backdropFilter: "blur(16px)",
      position: "sticky", top: 0, zIndex: 100,
    }}>
      <div className="header-inner" style={{
        maxWidth: 1200, margin: "0 auto", padding: "0 20px",
        display: "flex", alignItems: "center", height: 52, gap: 12,
      }}>
        {/* Logo */}
        <div
          style={{ display: "flex", alignItems: "center", gap: 7, cursor: "pointer", flexShrink: 0 }}
          onClick={() => nav("matches")}
        >
          <div style={{
            width: 28, height: 28, borderRadius: 7,
            display: "flex", alignItems: "center", justifyContent: "center",
            background: "linear-gradient(135deg, #22c55e, #16a34a)",
          }}>
            {Icons.coin(15)}
          </div>
          <span style={{ fontSize: 15, fontWeight: 800, letterSpacing: "-.3px" }}>
            Random<span style={{ color: "var(--green)" }}>Markets</span>
          </span>
        </div>

        {/* Desktop Nav */}
        <nav className="desktop-only" style={{ display: "flex", gap: 1, marginLeft: 16 }}>
          {navItems.map(x => (
            <button
              key={x.id}
              onClick={() => nav(x.id)}
              style={{
                padding: "5px 10px", borderRadius: 7, border: "none",
                background: page === x.id ? "rgba(255,255,255,.05)" : "none",
                color: page === x.id ? "var(--text)" : "var(--text-secondary)",
                fontSize: 12, fontWeight: 500, cursor: "pointer",
                fontFamily: "var(--font)", transition: "all .12s",
              }}
            >
              {x.label}
            </button>
          ))}
          {/* More dropdown */}
          <div style={{ position: "relative" }}>
            <button
              onClick={() => setMoreOpen(!moreOpen)}
              style={{
                padding: "5px 8px", borderRadius: 7, border: "none",
                background: ["faq", "about", "terms", "privacy"].includes(page) ? "rgba(255,255,255,.05)" : "none",
                color: "var(--text-secondary)", fontSize: 12, fontWeight: 500,
                cursor: "pointer", fontFamily: "var(--font)",
                display: "flex", alignItems: "center", gap: 3,
              }}
            >
              More {Icons.chevDown(11)}
            </button>
            {moreOpen && (
              <div style={{
                position: "absolute", top: 36, right: 0,
                background: "var(--card)", border: "1px solid var(--border-hover)",
                borderRadius: 10, padding: 4, minWidth: 160, zIndex: 50,
                boxShadow: "0 10px 32px rgba(0,0,0,.4)",
              }}>
                {moreItems.map(x => (
                  <button
                    key={x.id}
                    onClick={() => nav(x.id)}
                    style={{
                      width: "100%", textAlign: "left", padding: "8px 10px",
                      border: "none", background: page === x.id ? "rgba(255,255,255,.03)" : "none",
                      color: "var(--text)", fontSize: 12, cursor: "pointer",
                      borderRadius: 6, display: "flex", alignItems: "center",
                      gap: 7, fontFamily: "var(--font)",
                    }}
                  >
                    {x.icon} {x.label}
                  </button>
                ))}
              </div>
            )}
          </div>
        </nav>

        {/* Spacer */}
        <div style={{ flex: 1 }} />

        {/* Wallet */}
        <div className="header-actions" style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div style={{
            display: "flex", alignItems: "center", gap: 5,
            background: "var(--card)", border: "1px solid var(--border)",
            borderRadius: 9, padding: "5px 10px",
          }}>
            {Icons.coin(14)}
            <span style={{ fontWeight: 700, fontFamily: MN, fontSize: 12 }}>{balance.toLocaleString()}</span>
          </div>
          <button style={{
            background: "linear-gradient(135deg, var(--usdc), #1a5fb4)",
            border: "none", color: "#fff", padding: "6px 12px",
            borderRadius: 9, fontSize: 11, fontWeight: 600,
            cursor: "pointer", fontFamily: "var(--font)",
            display: "flex", alignItems: "center", gap: 4,
          }}>
            {Icons.wallet(13)} <span className="desktop-only">Connect</span>
          </button>
        </div>
      </div>
    </header>
  );
}

export function BottomNav({ page, onNavigate }) {
  const items = [
    { id: "matches", label: "Markets", icon: Icons.home },
    { id: "leaderboard", label: "Ranks", icon: Icons.trophy },
    { id: "bets", label: "My Bets", icon: Icons.history },
    { id: "referral", label: "Refer", icon: Icons.gift },
    { id: "faq", label: "More", icon: Icons.menu },
  ];
  const morePages = ["faq", "terms", "privacy", "about"];

  return (
    <nav className="bottom-nav">
      {items.map(x => (
        <button
          key={x.id}
          className={`bottom-nav-item ${page === x.id || (x.id === "faq" && morePages.includes(page)) ? "active" : ""}`}
          onClick={() => onNavigate(x.id)}
        >
          {x.icon(19)}
          <span>{x.label}</span>
        </button>
      ))}
    </nav>
  );
}
