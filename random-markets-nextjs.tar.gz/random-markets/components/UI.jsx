"use client";
import { useState, useEffect } from "react";
import { AVATAR_COLORS, SYM } from "@/lib/constants";
import { Icons, HeadsSVG, TailsSVG, LiveDot } from "./Icons";

const MN = "var(--mono)";

export function Avatar({ user, size = 30 }) {
  const c = AVATAR_COLORS[user.colorIdx % AVATAR_COLORS.length];
  return (
    <div style={{
      width: size, height: size, borderRadius: size > 26 ? 9 : 6,
      background: `linear-gradient(135deg, ${c[0]}, ${c[1]})`,
      display: "flex", alignItems: "center", justifyContent: "center",
      fontSize: size * 0.3, fontWeight: 700, color: "#fff", flexShrink: 0,
    }}>
      {user.initials}
    </div>
  );
}

export function AnimatedCoin({ flipping, result }) {
  const [rot, setRot] = useState(0);
  useEffect(() => {
    if (!flipping) return;
    let frame, r = 0;
    const animate = () => {
      r += 18;
      setRot(r);
      if (r < 1800) frame = requestAnimationFrame(animate);
      else setRot(result === "heads" ? 0 : 180);
    };
    frame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frame);
  }, [flipping, result]);

  const isH = Math.floor(rot / 180) % 2 === 0;
  return (
    <div style={{ width: 90, height: 90, perspective: 600, margin: "0 auto" }}>
      <div style={{
        width: "100%", height: "100%", borderRadius: "50%",
        transform: `rotateX(${rot}deg)`,
        transition: flipping ? "none" : "transform 0.3s",
        background: isH ? "linear-gradient(135deg, #22c55e, #16a34a)" : "linear-gradient(135deg, #ef4444, #dc2626)",
        display: "flex", alignItems: "center", justifyContent: "center",
        boxShadow: `0 0 24px ${isH ? "rgba(34,197,94,.25)" : "rgba(239,68,68,.25)"}, inset 0 -2px 8px rgba(0,0,0,.3)`,
        border: "2px solid rgba(255,255,255,.1)",
      }}>
        <span style={{ fontSize: 36, fontWeight: 900, color: "#fff", textShadow: "0 2px 4px rgba(0,0,0,.4)" }}>
          {isH ? "H" : "T"}
        </span>
      </div>
    </div>
  );
}

export function MatchCard({ match, index, onClick }) {
  const m = match;
  return (
    <div
      className={`match-card ${m.status}`}
      onClick={onClick}
      style={{ animation: `fadeUp 0.3s ease backwards`, animationDelay: `${index * 0.025}s` }}
    >
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
          <Avatar user={m.creator} size={28} />
          <div>
            <div style={{ fontWeight: 600, fontSize: 12 }}>{m.creator.name}</div>
            <div style={{ fontSize: 10, color: "var(--text-muted)" }}>
              picks <span style={{ color: m.creatorChoice === "heads" ? "var(--green)" : "var(--red)", fontWeight: 600 }}>
                {m.creatorChoice === "heads" ? "Heads" : "Tails"}
              </span>
            </div>
          </div>
        </div>
        {m.status === "live" && (
          <div style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 10, fontWeight: 700, color: "var(--green)" }}>
            <LiveDot /> LIVE
          </div>
        )}
        {m.status === "completed" && (
          <span className="badge" style={{
            background: m.result === "heads" ? "var(--green-dim)" : "var(--red-dim)",
            color: m.result === "heads" ? "var(--green)" : "var(--red)",
          }}>
            {m.result === "heads" ? "Heads" : "Tails"}
          </span>
        )}
      </div>

      {/* Stake */}
      <div style={{ textAlign: "center", marginBottom: 10 }}>
        <div style={{ fontSize: 8, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: 1.2, fontWeight: 700, marginBottom: 1 }}>Stake</div>
        <div style={{ fontSize: 20, fontWeight: 800, fontFamily: MN, color: "var(--green)" }}>
          ${m.betAmount.toLocaleString()}
          <span style={{ fontSize: 10, color: "var(--text-muted)", fontWeight: 500, marginLeft: 3 }}>{SYM}</span>
        </div>
      </div>

      {/* Odds bar */}
      <div style={{ marginBottom: 10 }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 3, fontSize: 9, fontWeight: 600 }}>
          <span style={{ color: "var(--green)" }}>Heads 50%</span>
          <span style={{ color: "var(--red)" }}>Tails 50%</span>
        </div>
        <div style={{ display: "flex", height: 3, borderRadius: 2, overflow: "hidden" }}>
          <div style={{ width: "50%", background: "linear-gradient(90deg, #22c55e, #16a34a)" }} />
          <div style={{ width: "50%", background: "linear-gradient(90deg, #dc2626, #ef4444)" }} />
        </div>
      </div>

      {/* Actions */}
      {m.status === "live" && (
        <div style={{ display: "flex", gap: 6 }}>
          <button className="btn-heads" onClick={e => e.stopPropagation()}>Heads</button>
          <button className="btn-tails" onClick={e => e.stopPropagation()}>Tails</button>
        </div>
      )}
      {m.status === "completed" && (
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span style={{ fontSize: 10, color: "var(--text-muted)", fontFamily: MN }}>${(m.betAmount * 2).toLocaleString()} vol</span>
          <span style={{ fontSize: 10, color: "var(--text-muted)" }}>{m.timeAgo}</span>
        </div>
      )}
    </div>
  );
}

export function GeoDisclaimer({ onNavigate }) {
  return (
    <div style={{
      marginTop: 28, padding: "10px 14px",
      background: "rgba(239,68,68,.03)", border: "1px solid rgba(239,68,68,.08)",
      borderRadius: 9, display: "flex", alignItems: "flex-start", gap: 7,
    }}>
      {Icons.info(12)}
      <p style={{ fontSize: 10, color: "var(--text-secondary)", lineHeight: 1.5 }}>
        <strong style={{ color: "var(--red)" }}>Restricted Jurisdictions:</strong> This platform is not available to residents of certain countries. By using RandomMarkets you confirm you are legally permitted to participate. See{" "}
        <span onClick={() => onNavigate("terms")} style={{ color: "var(--usdc)", cursor: "pointer", textDecoration: "underline" }}>Terms</span>.
      </p>
    </div>
  );
}
