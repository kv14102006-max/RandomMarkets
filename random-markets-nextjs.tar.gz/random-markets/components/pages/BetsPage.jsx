"use client";
import { Icons } from "@/components/Icons";
import { SYM } from "@/lib/constants";

const MN = "var(--mono)";

export default function BetsPage({ history }) {
  return (
    <div style={{ animation: "fadeUp 0.3s ease" }}>
      <h1 style={{ fontSize: 20, fontWeight: 800, marginBottom: 16, display: "flex", alignItems: "center", gap: 7 }}>
        {Icons.history(18)} My Bets
      </h1>

      {/* Stats */}
      <div className="grid-4" style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 10, marginBottom: 20 }}>
        {[
          { label: "Total Bets", value: "142" },
          { label: "Win Rate", value: "58.4%" },
          { label: "Profit", value: "+$2,847", color: "var(--green)" },
          { label: "Best Streak", value: "7W" },
        ].map((s, i) => (
          <div key={i} style={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 11, padding: 14 }}>
            <div style={{ color: "var(--text-secondary)", fontSize: 11, marginBottom: 5 }}>{s.label}</div>
            <div style={{ fontSize: 18, fontWeight: 800, fontFamily: MN, color: s.color || "var(--text)" }}>{s.value}</div>
          </div>
        ))}
      </div>

      {/* History list */}
      <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
        {history.map((h, i) => (
          <div
            key={h.id}
            style={{
              background: "var(--card)", border: "1px solid var(--border)",
              borderRadius: 10, padding: "10px 14px",
              display: "flex", alignItems: "center", gap: 10,
              animation: `fadeUp 0.3s ease backwards`, animationDelay: `${i * 0.02}s`,
            }}
          >
            <div style={{
              width: 32, height: 32, borderRadius: 8,
              display: "flex", alignItems: "center", justifyContent: "center",
              background: h.won ? "var(--green-dim)" : "var(--red-dim)",
              border: `1px solid ${h.won ? "var(--green-border)" : "var(--red-border)"}`,
              flexShrink: 0,
            }}>
              {h.won ? Icons.check(12) : Icons.xCircle(12)}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
                <span style={{ fontWeight: 600, fontSize: 12 }}>vs {h.opponent.name}</span>
                <span className="badge" style={{
                  background: h.result === "heads" ? "var(--green-dim)" : "var(--red-dim)",
                  color: h.result === "heads" ? "var(--green)" : "var(--red)",
                }}>
                  {h.result === "heads" ? "H" : "T"}
                </span>
              </div>
              <div style={{ color: "var(--text-muted)", fontSize: 10, marginTop: 1 }}>
                {h.time} · {h.wasCreator ? "Creator" : "Joiner"} · Fee: ${h.fee.toFixed(2)}
              </div>
            </div>
            <div style={{ textAlign: "right", flexShrink: 0 }}>
              <div style={{ fontWeight: 700, fontSize: 13, fontFamily: MN, color: h.won ? "var(--green)" : "var(--red)" }}>
                {h.netAmount >= 0 ? "+" : ""}${Math.abs(h.netAmount).toFixed(2)}
              </div>
              <div style={{ fontSize: 9, color: "var(--text-muted)", fontFamily: MN }}>${h.amount} {SYM}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
