"use client";

const items = [
  "Data Collection — We collect wallet addresses and on-chain transaction data only. No personal info required.",
  "Cookies — Minimal analytics cookies. No third-party ad cookies.",
  "On-Chain Data — All match data is on the Base blockchain and publicly visible.",
  "Third Parties — We do not sell or share user data.",
  "Geo-Restriction — We may collect IP-based location data solely for jurisdiction enforcement.",
  "Security — Smart contracts audited. Industry-standard practices.",
  "Your Rights — Disconnect your wallet anytime. On-chain data is immutable.",
  "Contact — Reach us via official channels for privacy inquiries.",
];

export default function PrivacyPage() {
  return (
    <div style={{ animation: "fadeUp 0.3s ease", maxWidth: 640, margin: "0 auto" }}>
      <h1 style={{ fontSize: 20, fontWeight: 800, marginBottom: 16 }}>Privacy Policy</h1>
      <div style={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 12, padding: 22 }}>
        {items.map((t, i) => (
          <p key={i} style={{ color: "var(--text-secondary)", fontSize: 12, lineHeight: 1.7, marginBottom: 10 }}>{t}</p>
        ))}
        <p style={{ color: "var(--text-muted)", fontSize: 10, marginTop: 14 }}>Last updated: February 2026</p>
      </div>
    </div>
  );
}
