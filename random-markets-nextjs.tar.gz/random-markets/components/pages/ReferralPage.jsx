"use client";
import { Icons } from "@/components/Icons";
import { SYM } from "@/lib/constants";

const MN = "var(--mono)";

export default function ReferralPage() {
  return (
    <div style={{ animation: "fadeUp 0.3s ease" }}>
      <h1 style={{ fontSize: 20, fontWeight: 800, marginBottom: 4, display: "flex", alignItems: "center", gap: 7 }}>
        {Icons.gift(18)} Referral Program
      </h1>
      <p style={{ color: "var(--text-secondary)", fontSize: 12, marginBottom: 20 }}>
        Earn 25% of platform fees from every referred user
      </p>

      {/* Link */}
      <div style={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 12, padding: 20, marginBottom: 14 }}>
        <div style={{ fontSize: 9, fontWeight: 700, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: 1, marginBottom: 6 }}>
          Your Referral Link
        </div>
        <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
          <div style={{
            flex: 1, background: "var(--bg)", border: "1px solid var(--border)",
            borderRadius: 8, padding: "8px 12px", fontFamily: MN, fontSize: 11,
            color: "var(--text-secondary)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
          }}>
            https://randommarkets.xyz/?ref=CW42x9
          </div>
          <button className="btn-primary" style={{ padding: "8px 12px", flexShrink: 0, fontSize: 11 }}>
            {Icons.copy(12)} Copy
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid-4" style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 10, marginBottom: 20 }}>
        {[
          { label: "Referrals", value: "23" },
          { label: "Their Volume", value: "$12,450" },
          { label: "Earnings", value: "$124.50", color: "var(--green)" },
          { label: "Pending", value: "$18.20", color: "var(--yellow)" },
        ].map((s, i) => (
          <div key={i} style={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 11, padding: 14 }}>
            <div style={{ color: "var(--text-secondary)", fontSize: 11, marginBottom: 5 }}>{s.label}</div>
            <div style={{ fontSize: 18, fontWeight: 800, fontFamily: MN, color: s.color || "var(--text)" }}>{s.value}</div>
          </div>
        ))}
      </div>

      {/* How it works */}
      <div style={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 12, padding: 18 }}>
        <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 10 }}>How it works</div>
        {[
          "Share your unique referral link with friends",
          "They sign up and start flipping coins",
          "You earn 25% of platform fees from their matches",
          "Claim USDC earnings anytime — paid on-chain",
        ].map((s, i) => (
          <div key={i} style={{ display: "flex", gap: 8, alignItems: "flex-start", marginBottom: 8 }}>
            <div style={{
              width: 20, height: 20, borderRadius: "50%",
              background: "var(--green-dim)", border: "1px solid var(--green-border)",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 10, fontWeight: 700, color: "var(--green)", flexShrink: 0,
            }}>{i + 1}</div>
            <span style={{ fontSize: 12, color: "var(--text-secondary)", lineHeight: 1.5 }}>{s}</span>
          </div>
        ))}
        <button className="btn-primary" style={{ marginTop: 6, width: "100%", justifyContent: "center", padding: 11, fontSize: 12 }}>
          Claim $18.20 {SYM}
        </button>
      </div>
    </div>
  );
}
