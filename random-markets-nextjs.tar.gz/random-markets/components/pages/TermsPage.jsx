"use client";

const terms = [
  "1. Eligibility — You must be at least 18 years old. Users from restricted jurisdictions are prohibited from using this platform.",
  "2. Risks — Coin flip outcomes are random. You may lose your entire bet. Only wager what you can afford to lose.",
  "3. Fees — Creator fee: 1.5%. Joiner fee: 2.5%. Fees are non-refundable once a match is resolved.",
  "4. USDC — All bets are in USDC on Base. We are not responsible for network fees or failed transactions.",
  "5. Randomness — Results are determined by Pyth Entropy's verifiable randomness. We cannot influence outcomes.",
  "6. Cancellation — Creators may cancel unjoined matches. Bet refunded; creator fee retained.",
  "7. Referrals — Abuse of referral system may result in restriction.",
  "8. No Warranty — Provided as-is with no guarantees.",
  "9. Modifications — We may modify these terms at any time. Continued use means acceptance.",
  "10. Liability — We are not liable for losses from betting, network issues, or smart contract bugs.",
];

export default function TermsPage() {
  return (
    <div style={{ animation: "fadeUp 0.3s ease", maxWidth: 640, margin: "0 auto" }}>
      <h1 style={{ fontSize: 20, fontWeight: 800, marginBottom: 16 }}>Terms & Conditions</h1>
      <div style={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 12, padding: 22 }}>
        {terms.map((t, i) => (
          <p key={i} style={{ color: "var(--text-secondary)", fontSize: 12, lineHeight: 1.7, marginBottom: 10 }}>{t}</p>
        ))}
        <p style={{ color: "var(--text-muted)", fontSize: 10, marginTop: 14 }}>Last updated: February 2026</p>
      </div>
    </div>
  );
}
