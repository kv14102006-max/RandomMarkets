"use client";
import { Icons } from "@/components/Icons";
import { Avatar } from "@/components/UI";

const MN = "var(--mono)";

export default function LeaderboardPage({ data }) {
  return (
    <div style={{ animation: "fadeUp 0.3s ease" }}>
      <div style={{ marginBottom: 20 }}>
        <h1 style={{ fontSize: 20, fontWeight: 800, display: "flex", alignItems: "center", gap: 7 }}>
          {Icons.trophy(18)} Leaderboard
        </h1>
        <p style={{ color: "var(--text-secondary)", fontSize: 12, marginTop: 3 }}>Top players by profit</p>
      </div>

      {/* Podium */}
      <div className="podium-grid" style={{ display: "grid", gridTemplateColumns: "1fr 1.1fr 1fr", gap: 10, marginBottom: 24, alignItems: "end" }}>
        {[1, 0, 2].map(idx => {
          const p = data[idx];
          const isFirst = idx === 0;
          const labels = ["1st", "2nd", "3rd"];
          const colors = ["#eab308", "#94a3b8", "#d97706"];
          return (
            <div
              key={idx}
              style={{
                background: "var(--card)", borderRadius: 12, textAlign: "center",
                border: `1px solid ${isFirst ? "rgba(234,179,8,.2)" : "var(--border)"}`,
                padding: isFirst ? 24 : 18,
                animation: `fadeUp 0.4s ease backwards`, animationDelay: `${idx * 0.07}s`,
                order: idx === 0 ? 0 : idx === 1 ? -1 : 1,
              }}
            >
              <div style={{ fontSize: 9, fontWeight: 700, color: colors[idx], textTransform: "uppercase", letterSpacing: 1, marginBottom: 8 }}>
                {labels[idx]}
              </div>
              <div style={{ display: "flex", justifyContent: "center", marginBottom: 8 }}>
                <Avatar user={p} size={isFirst ? 44 : 36} />
              </div>
              {isFirst && <div style={{ marginBottom: 1 }}>{Icons.crown(16)}</div>}
              <div style={{ fontWeight: 700, fontSize: 13 }}>{p.name}</div>
              <div style={{ color: "var(--green)", fontWeight: 800, fontSize: isFirst ? 18 : 15, fontFamily: MN, margin: "3px 0" }}>
                +${p.profit.toLocaleString()}
              </div>
              <div style={{ color: "var(--text-muted)", fontSize: 10 }}>
                {p.winRate}% WR · {p.totalWins}W
              </div>
            </div>
          );
        })}
      </div>

      {/* Table */}
      <div style={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 11, overflow: "hidden" }}>
        <div
          className="lb-row"
          style={{
            display: "grid", gridTemplateColumns: "36px 1fr 70px 60px 90px",
            alignItems: "center", padding: "8px 14px",
            borderBottom: "1px solid var(--border)",
            color: "var(--text-muted)", fontSize: 9, fontWeight: 700,
            textTransform: "uppercase", letterSpacing: 0.8,
          }}
        >
          <span>#</span><span>Player</span>
          <span className="hide-mobile" style={{ textAlign: "right" }}>Win Rate</span>
          <span style={{ textAlign: "right" }}>Wins</span>
          <span style={{ textAlign: "right" }}>Profit</span>
        </div>
        {data.slice(3).map((p, i) => (
          <div
            key={i}
            className="lb-row"
            style={{
              display: "grid", gridTemplateColumns: "36px 1fr 70px 60px 90px",
              alignItems: "center", padding: "8px 14px",
              borderBottom: "1px solid rgba(28,35,51,.4)",
            }}
          >
            <span style={{ fontWeight: 700, color: "var(--text-muted)", fontFamily: MN, fontSize: 11 }}>{p.rank}</span>
            <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
              <Avatar user={p} size={26} />
              <span style={{ fontWeight: 600, fontSize: 12 }}>{p.name}</span>
            </div>
            <span className="hide-mobile" style={{ textAlign: "right", fontFamily: MN, fontSize: 11 }}>{p.winRate}%</span>
            <span style={{ textAlign: "right", fontFamily: MN, fontSize: 11 }}>{p.totalWins}</span>
            <span style={{
              textAlign: "right", fontWeight: 700, fontFamily: MN, fontSize: 11,
              color: p.profit >= 0 ? "var(--green)" : "var(--red)",
            }}>
              {p.profit >= 0 ? "+" : ""}${p.profit.toLocaleString()}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
