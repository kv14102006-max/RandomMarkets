"use client";
import { Icons } from "@/components/Icons";

const faqs = [
  { q: "What is RandomMarkets?", a: "A provably fair coin flip platform on Base. Create or join matches, pick Heads or Tails, and the winner takes 2x the bet. All outcomes are determined by Pyth Entropy's verifiable randomness." },
  { q: "What currency do I use?", a: "All bets are placed in USDC (a stablecoin pegged to $1 USD). You need USDC on the Base network in your wallet." },
  { q: "What are the fees?", a: "Creators pay 1.5% and joiners pay 2.5%, both charged on top of the bet amount. The winner always receives exactly 2x the bet." },
  { q: "How is randomness guaranteed?", a: "We use Pyth Entropy, a commit-reveal protocol where both you and the provider contribute randomness. Neither party can predict or manipulate the outcome." },
  { q: "How do I connect?", a: "Click 'Connect' and use any supported wallet via RainbowKit — MetaMask, Coinbase Wallet, Rainbow, WalletConnect, and more." },
  { q: "Can I cancel a match?", a: "Yes, if nobody has joined yet. Your bet is refunded but the creator fee is not." },
  { q: "How does referral work?", a: "Share your link. You earn 25% of platform fees from every match your referrals play. Claimable on-chain in USDC." },
];

export default function FaqPage() {
  return (
    <div style={{ animation: "fadeUp 0.3s ease", maxWidth: 640, margin: "0 auto" }}>
      <h1 style={{ fontSize: 20, fontWeight: 800, marginBottom: 16, display: "flex", alignItems: "center", gap: 7 }}>
        {Icons.help(18)} How It Works
      </h1>
      {faqs.map((f, i) => (
        <div key={i} style={{
          background: "var(--card)", border: "1px solid var(--border)",
          borderRadius: 11, padding: "14px 18px", marginBottom: 6,
        }}>
          <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 4 }}>{f.q}</div>
          <div style={{ color: "var(--text-secondary)", fontSize: 12, lineHeight: 1.6 }}>{f.a}</div>
        </div>
      ))}
    </div>
  );
}
