"use client";
import { useState } from "react";
import { CATEGORIES, SYM } from "@/lib/constants";
import { Icons } from "@/components/Icons";
import { MatchCard } from "@/components/UI";

export default function MatchesPage({ matches, onCreateClick, onMatchClick }) {
  const [cat, setCat] = useState("all");
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState("newest");
  const [statusFilter, setSf] = useState("all");

  const filtered = matches
    .filter(m => {
      if (statusFilter !== "all" && m.status !== statusFilter) return false;
      if (cat !== "all") {
        const a = m.betAmount;
        const ranges = { "1-50": [1, 50], "50-250": [50, 250], "250-1k": [250, 1000], "1k+": [1000, Infinity] };
        const [mn, mx] = ranges[cat] || [0, Infinity];
        if (a < mn || a > mx) return false;
      }
      if (search) {
        const q = search.toLowerCase();
        return m.creator.name.toLowerCase().includes(q) || (m.opponent?.name.toLowerCase().includes(q));
      }
      return true;
    })
    .sort((a, b) =>
      sort === "newest" ? b.createdAt - a.createdAt :
      sort === "highest" ? b.betAmount - a.betAmount : a.betAmount - b.betAmount
    );

  return (
    <div style={{ animation: "fadeUp 0.3s ease" }}>
      {/* Mobile search */}
      <div style={{ marginBottom: 12, display: "none" }} className="mobile-search">
        <div style={{ position: "relative" }}>
          <div style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)", color: "var(--text-muted)" }}>
            {Icons.search(14)}
          </div>
          <input
            className="input"
            placeholder="Search matches..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            style={{ paddingLeft: 32, height: 38, fontSize: 13 }}
          />
        </div>
      </div>

      {/* Filter row */}
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14, flexWrap: "wrap" }}>
        <div style={{ display: "flex", gap: 3, overflow: "auto", flex: 1, paddingBottom: 1 }}>
          {CATEGORIES.map(c => (
            <button
              key={c.id}
              className={`chip ${cat === c.id ? "active" : ""}`}
              onClick={() => setCat(c.id)}
            >{c.label}</button>
          ))}
        </div>

        {/* Status toggle */}
        <div style={{ display: "flex", gap: 1, background: "var(--card)", borderRadius: 7, padding: 2, border: "1px solid var(--border)" }}>
          {["all", "live", "completed"].map(s => (
            <button
              key={s}
              onClick={() => setSf(s)}
              style={{
                padding: "3px 10px", borderRadius: 5, border: "none",
                fontSize: 10, fontWeight: 600, cursor: "pointer",
                background: statusFilter === s ? "rgba(255,255,255,.05)" : "transparent",
                color: statusFilter === s ? "var(--text)" : "var(--text-muted)",
                fontFamily: "var(--font)",
              }}
            >{s === "all" ? "All" : s === "live" ? "Live" : "Settled"}</button>
          ))}
        </div>

        {/* Sort */}
        <select
          value={sort}
          onChange={e => setSort(e.target.value)}
          style={{
            background: "var(--card)", border: "1px solid var(--border)",
            borderRadius: 7, padding: "4px 8px", color: "var(--text)",
            fontSize: 10, cursor: "pointer", outline: "none", fontFamily: "var(--font)",
          }}
        >
          <option value="newest">Newest</option>
          <option value="highest">Highest</option>
          <option value="lowest">Lowest</option>
        </select>

        {/* Desktop search */}
        <div className="desktop-only" style={{ position: "relative", width: 200 }}>
          <div style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)", color: "var(--text-muted)" }}>
            {Icons.search(13)}
          </div>
          <input
            className="input"
            placeholder="Search..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            style={{ paddingLeft: 30, height: 32, fontSize: 11 }}
          />
        </div>

        {/* Create button */}
        <button className="btn-primary" onClick={onCreateClick} style={{ padding: "7px 14px", fontSize: 11 }}>
          {Icons.plus(12)} Create
        </button>
      </div>

      {/* Match grid */}
      <div className="match-grid" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 10 }}>
        {filtered.map((m, i) => (
          <MatchCard key={m.id} match={m} index={i} onClick={() => onMatchClick(m)} />
        ))}
      </div>

      {filtered.length === 0 && (
        <div style={{ textAlign: "center", padding: 50, color: "var(--text-muted)" }}>
          <div style={{ fontSize: 13, fontWeight: 600 }}>No matches found</div>
          <div style={{ fontSize: 11, marginTop: 3 }}>Try changing filters or create a new one</div>
        </div>
      )}
    </div>
  );
}
