"use client";
import { SYM } from "@/lib/constants";

export default function AboutPage() {
  return (
    <div style={{ animation: "fadeUp 0.3s ease", maxWidth: 640, margin: "0 auto" }}>
      <h1 style={{ fontSize: 20, fontWeight: 800, marginBottom: 16 }}>About RandomMarkets</h1>

      <div style={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 12, padding: 22, marginBottom: 14 }}>
        <p style={{ color: "var(--text-secondary)", fontSize: 13, lineHeight: 1.7, marginBottom: 14 }}>
          RandomMarkets is a provably fair coin flip platform built on Base. We believe online betting should be transparent, verifiable, and trustless.
        </p>
        <p style={{ color: "var(--text-secondary)", fontSize: 13, lineHeight: 1.7, marginBottom: 14 }}>
          Every flip is powered by Pyth Entropy — a cryptographic commit-reveal protocol ensuring neither the platform nor any player can influence outcomes. All bets settle in {SYM} for price stability.
        </p>
        <p style={{ color: "var(--text-secondary)", fontSize: 13, lineHeight: 1.7 }}>
          Built on Base for low fees and fast confirmations. Open-source smart contracts. No house edge beyond transparent platform fees.
        </p>
      </div>

      <div className="grid-4" style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10 }}>
        {[
          { label: "Chain", value: "Base" },
          { label: "Currency", value: SYM },
          { label: "Randomness", value: "Pyth Entropy" },
        ].map((s, i) => (
          <div key={i} style={{
            background: "var(--card)", border: "1px solid var(--border)",
            borderRadius: 11, padding: 14, textAlign: "center",
          }}>
            <div style={{ color: "var(--text-muted)", fontSize: 9, marginBottom: 3, fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.5 }}>
              {s.label}
            </div>
            <div style={{ fontSize: 14, fontWeight: 800 }}>{s.value}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
