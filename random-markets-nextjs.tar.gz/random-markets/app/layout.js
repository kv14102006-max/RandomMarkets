import "@/styles/globals.css";

export const metadata = {
  title: "RandomMarkets — Provably Fair Coin Flips on Base",
  description: "Create or join USDC coin flip matches with verifiable randomness powered by Pyth Entropy on Base.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
