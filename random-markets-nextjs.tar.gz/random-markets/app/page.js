"use client";
import { useState } from "react";
import { genMatches, genLeaderboard, genHistory, CATEGORIES, SYM, CREATOR_FEE, JOINER_FEE } from "@/lib/constants";
import { Icons } from "@/components/Icons";
import { Avatar, MatchCard, GeoDisclaimer } from "@/components/UI";
import { Header, BottomNav } from "@/components/Navigation";
import { CreateModal, DetailModal } from "@/components/Modals";
import MatchesPage from "@/components/pages/MatchesPage";
import LeaderboardPage from "@/components/pages/LeaderboardPage";
import BetsPage from "@/components/pages/BetsPage";
import ReferralPage from "@/components/pages/ReferralPage";
import FaqPage from "@/components/pages/FaqPage";
import TermsPage from "@/components/pages/TermsPage";
import PrivacyPage from "@/components/pages/PrivacyPage";
import AboutPage from "@/components/pages/AboutPage";

export default function Home() {
  const [page, setPage] = useState("matches");
  const [matches] = useState(genMatches);
  const [leaderboard] = useState(genLeaderboard);
  const [history] = useState(genHistory);
  const [showCreate, setShowCreate] = useState(false);
  const [showDetail, setShowDetail] = useState(null);
  const [balance] = useState(4827);

  const nav = (p) => { setPage(p); window.scrollTo(0, 0); };
  const mainPages = ["matches", "leaderboard", "bets", "referral"];

  return (
    <div style={{ minHeight: "100vh" }}>
      <Header page={page} onNavigate={nav} balance={balance} />
      <BottomNav page={page} onNavigate={nav} />

      <main className="main-content" style={{ maxWidth: 1200, margin: "0 auto", padding: "16px 16px 20px" }}>
        {page === "matches" && (
          <MatchesPage
            matches={matches}
            onCreateClick={() => setShowCreate(true)}
            onMatchClick={(m) => setShowDetail(m)}
          />
        )}
        {page === "leaderboard" && <LeaderboardPage data={leaderboard} />}
        {page === "bets" && <BetsPage history={history} />}
        {page === "referral" && <ReferralPage />}
        {page === "faq" && <FaqPage />}
        {page === "terms" && <TermsPage />}
        {page === "privacy" && <PrivacyPage />}
        {page === "about" && <AboutPage />}

        {mainPages.includes(page) && <GeoDisclaimer onNavigate={nav} />}
      </main>

      {/* Footer */}
      <footer style={{ borderTop: "1px solid var(--border)", padding: 16, maxWidth: 1200, margin: "32px auto 0" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 10 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 12, fontWeight: 700 }}>
            {Icons.coin(14)} Random<span style={{ color: "var(--green)" }}>Markets</span>
          </div>
          <div style={{ display: "flex", gap: 14 }}>
            {[{ l: "Terms", p: "terms" }, { l: "Privacy", p: "privacy" }, { l: "FAQ", p: "faq" }, { l: "About", p: "about" }].map(x => (
              <span key={x.p} onClick={() => nav(x.p)} style={{ color: "var(--text-muted)", fontSize: 11, cursor: "pointer" }}>{x.l}</span>
            ))}
          </div>
          <div style={{ color: "var(--text-muted)", fontSize: 10 }}>Base · Pyth Entropy · USDC</div>
        </div>
      </footer>

      {showCreate && <CreateModal close={() => setShowCreate(false)} balance={balance} />}
      {showDetail && <DetailModal match={showDetail} close={() => setShowDetail(null)} balance={balance} />}
    </div>
  );
}
