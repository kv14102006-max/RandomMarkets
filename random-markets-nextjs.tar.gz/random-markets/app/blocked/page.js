export default function BlockedPage() {
  return (
    <div style={{
      minHeight: "100vh",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      flexDirection: "column",
      padding: 40,
      textAlign: "center",
    }}>
      <div style={{ fontSize: 48, marginBottom: 16 }}>
        <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
          <line x1="9" y1="9" x2="15" y2="15" />
          <line x1="15" y1="9" x2="9" y2="15" />
        </svg>
      </div>
      <h1 style={{ fontSize: 24, fontWeight: 800, marginBottom: 8 }}>
        Service Unavailable
      </h1>
      <p style={{ color: "var(--text-secondary)", fontSize: 14, maxWidth: 400, lineHeight: 1.6 }}>
        RandomMarkets is not available in your region due to regulatory restrictions. 
        We apologize for the inconvenience.
      </p>
    </div>
  );
}
