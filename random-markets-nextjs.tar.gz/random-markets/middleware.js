import { NextResponse } from "next/server";

// ═══════════════════════════════════════════════════════════════
//  GEO-RESTRICTION MIDDLEWARE
//  Enable when you're ready — set BLOCKED_COUNTRIES and uncomment the check.
//  Vercel/Cloudflare automatically provides geo headers.
// ═══════════════════════════════════════════════════════════════

// Add country codes to block (ISO 3166-1 alpha-2)
// Examples: "US", "GB", "AU", "FR", "NL"
const BLOCKED_COUNTRIES = [
  // "US",
  // "GB",
];

export function middleware(request) {
  // Uncomment below to enable geo-blocking:
  //
  // const country = request.geo?.country || request.headers.get("x-vercel-ip-country") || "";
  //
  // if (BLOCKED_COUNTRIES.includes(country)) {
  //   return NextResponse.rewrite(new URL("/blocked", request.url));
  // }

  return NextResponse.next();
}

export const config = {
  matcher: [
    // Apply to all routes except static files and API
    "/((?!_next/static|_next/image|favicon.ico|api).*)",
  ],
};
